import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { MOCK_BOOKINGS } from '../data/mockVehicles'
import StatusBadge from '../components/common/StatusBadge'
import { message } from 'antd'

export default function MyBookingsPage() {
  const [activeTab, setActiveTab] = useState('all')
  const [bookingsList, setBookingsList] = useState(MOCK_BOOKINGS)

  const tabs = [
    { id: 'all', label: 'All Trips' },
    { id: 'active', label: 'Active & Upcoming' },
    { id: 'completed', label: 'Completed' },
    { id: 'cancelled', label: 'Cancelled' }
  ]

  const filteredBookings = bookingsList.filter(b => {
    if (activeTab === 'all') return true
    if (activeTab === 'active') return b.booking_status === 'approved' || b.booking_status === 'requested'
    if (activeTab === 'completed') return b.booking_status === 'completed'
    if (activeTab === 'cancelled') return b.booking_status === 'cancelled'
    return true
  })

  const handleCancelBooking = (bookingId) => {
    setBookingsList(prev => prev.map(b => {
      if (b.id === bookingId) {
        return { ...b, booking_status: 'cancelled' }
      }
      return b
    }))
    message.info('Booking has been cancelled.')
  }

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <nav className="flex items-center gap-1.5 text-xs text-on-surface-variant font-semibold mb-2">
          <Link to="/home" className="hover:text-primary">Home</Link>
          <span>/</span>
          <span className="text-primary font-bold">My Bookings</span>
        </nav>

        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-on-surface tracking-tight">
              My Rental Trips
            </h1>
            <p className="text-xs sm:text-sm text-on-surface-variant mt-1">
              Track your reservations, view pickup hubs, and manage your trips.
            </p>
          </div>

          <Link
            to="/explore"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-primary-container text-on-primary font-bold text-xs hover:bg-electric-violet-hover self-start sm:self-auto transition-all shadow-sm"
          >
            <span className="material-symbols-outlined text-[16px]">add</span>
            <span>Book New Ride</span>
          </Link>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-border-purple-tint pb-1 overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === tab.id
                ? 'bg-primary-container text-on-primary shadow-sm'
                : 'text-on-surface-variant hover:bg-lavender-subtle hover:text-primary'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Bookings List */}
      {filteredBookings.length > 0 ? (
        <div className="flex flex-col gap-4">
          {filteredBookings.map(item => (
            <div
              key={item.id}
              className="bg-surface-card rounded-3xl border border-border-purple-tint p-5 sm:p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col lg:flex-row lg:items-center justify-between gap-5"
            >
              {/* Vehicle & Trip Info */}
              <div className="flex items-start sm:items-center gap-4">
                <img
                  src={item.vehicle.image}
                  alt={item.vehicle.model}
                  className="w-24 h-20 sm:w-28 sm:h-24 rounded-2xl object-cover shrink-0 border border-border-purple-tint bg-surface-container"
                />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-primary">
                      {item.vehicle.brand}
                    </span>
                    <StatusBadge status={item.booking_status} />
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-on-surface">
                    {item.vehicle.model}
                  </h3>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-on-surface-variant mt-2">
                    <div className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-primary">event</span>
                      <span>
                        {new Date(item.start_datetime).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} - {new Date(item.end_datetime).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-primary">schedule</span>
                      <span>{item.total_hours} Hours</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-primary">location_on</span>
                      <span>{item.vehicle.pickup_location}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Price and Actions */}
              <div className="flex sm:items-center justify-between lg:justify-end gap-5 pt-3 lg:pt-0 border-t lg:border-t-0 border-border-purple-tint">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">Total Paid</div>
                  <div className="text-xl font-extrabold text-primary">₹{item.total_amount.toLocaleString('en-IN')}</div>
                  <div className="text-[10px] text-emerald-600 font-semibold">Razorpay Test Mode</div>
                </div>

                <div className="flex items-center gap-2">
                  <Link
                    to={`/vehicle/${item.vehicle_id}`}
                    className="px-3.5 py-2 rounded-xl bg-surface-container-low text-on-surface font-bold text-xs hover:bg-lavender-subtle transition-colors"
                  >
                    View Vehicle
                  </Link>

                  {item.booking_status === 'approved' && (
                    <button
                      onClick={() => handleCancelBooking(item.id)}
                      className="px-3.5 py-2 rounded-xl bg-red-50 text-error font-bold text-xs hover:bg-red-100 transition-colors"
                    >
                      Cancel Trip
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-12 text-center flex flex-col items-center">
          <div className="w-16 h-16 rounded-2xl bg-lavender-subtle text-primary flex items-center justify-center mb-4">
            <span className="material-symbols-outlined text-[32px]">calendar_today</span>
          </div>
          <h3 className="text-lg font-bold text-on-surface">No bookings in this category</h3>
          <p className="text-xs sm:text-sm text-on-surface-variant max-w-sm mt-1">
            Browse our community fleet to find and rent your next ride easily.
          </p>
          <Link
            to="/explore"
            className="mt-5 px-5 py-2.5 rounded-xl bg-primary-container text-on-primary font-bold text-xs hover:bg-electric-violet-hover transition-all shadow-md"
          >
            Explore Vehicles
          </Link>
        </div>
      )}
    </div>
  )
}


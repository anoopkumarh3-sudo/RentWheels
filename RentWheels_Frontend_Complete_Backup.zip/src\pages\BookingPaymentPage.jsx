import React, { useState } from 'react'
import { useParams, useSearchParams, useNavigate, Link } from 'react-router-dom'
import { MOCK_VEHICLES, MOCK_USER } from '../data/mockVehicles'
import { message } from 'antd'

export default function BookingPaymentPage() {
  const { id } = useParams()
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()

  const vehicle = MOCK_VEHICLES.find(v => v.id === id) || MOCK_VEHICLES[0]

  const startParam = searchParams.get('start') || new Date().toISOString()
  const endParam = searchParams.get('end') || new Date(Date.now() + 48 * 3600 * 1000).toISOString()

  const [driverName, setDriverName] = useState(MOCK_USER.full_name)
  const [driverPhone, setDriverPhone] = useState(MOCK_USER.phone)
  const [licenseNumber, setLicenseNumber] = useState('DL-04-2021-9988776')
  const [paymentMethod, setPaymentMethod] = useState('razorpay_upi')
  const [paymentState, setPaymentState] = useState('form') // 'form', 'processing', 'success'
  const [bookingRefId, setBookingRefId] = useState('')

  // Calculate pricing
  const start = new Date(startParam).getTime()
  const end = new Date(endParam).getTime()
  const totalHours = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60)))
  const totalDays = Number((totalHours / 24).toFixed(1))

  let baseRental = 0
  if (totalHours >= 24) {
    baseRental = (Math.floor(totalHours / 24) * vehicle.daily_price) + ((totalHours % 24) * vehicle.hourly_price)
  } else {
    baseRental = totalHours * vehicle.hourly_price
  }

  const insuranceFee = 99
  const taxes = Math.round(baseRental * 0.05) // 5% GST
  const grandTotal = baseRental + insuranceFee + taxes

  const handlePayNow = () => {
    if (!licenseNumber.trim()) {
      message.error('Please enter a valid Driving License number.')
      return
    }

    setPaymentState('processing')

    // Simulate Razorpay Test Mode checkout verification
    setTimeout(() => {
      const generatedId = `RW-${Math.floor(100000 + Math.random() * 900000)}`
      setBookingRefId(generatedId)
      setPaymentState('success')
      message.success('Payment confirmed via Razorpay Test Mode!')
    }, 1500)
  }

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-1.5 text-xs text-on-surface-variant font-semibold">
        <Link to="/explore" className="hover:text-primary">Explore</Link>
        <span>/</span>
        <Link to={`/vehicle/${vehicle.id}`} className="hover:text-primary">{vehicle.brand} {vehicle.model}</Link>
        <span>/</span>
        <span className="text-primary font-bold">Checkout & Payment</span>
      </nav>

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-on-surface tracking-tight">Complete Your Booking</h1>
          <p className="text-xs sm:text-sm text-on-surface-variant mt-1">
            Review your driver credentials, trip schedule and proceed to Razorpay test payment.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-card border border-border-purple-tint text-xs font-semibold text-on-surface shadow-sm">
            <span className="material-symbols-outlined text-primary text-[16px]">lock</span>
            <span>256-Bit SSL Encrypted</span>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-lavender-subtle text-primary text-xs font-bold shadow-sm">
            <span className="material-symbols-outlined text-[16px]">bolt</span>
            <span>Instant Confirmation</span>
          </div>
        </div>
      </div>

      {/* Main Checkout View */}
      {paymentState !== 'success' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Form: Driver Credentials & Trip Details (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            {/* Driver Credentials Card */}
            <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-6 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-border-purple-tint mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-primary-container text-on-primary flex items-center justify-center">
                    <span className="material-symbols-outlined text-[18px]">badge</span>
                  </div>
                  <h2 className="text-base font-bold text-on-surface">Driver Verification</h2>
                </div>
                <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                  Profile Verified
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-on-surface-variant mb-1">
                    Driver Full Name
                  </label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    className="w-full h-11 px-3.5 bg-surface-container-low border border-border-purple-tint rounded-xl text-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary-container/20"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-on-surface-variant mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    className="w-full h-11 px-3.5 bg-surface-container-low border border-border-purple-tint rounded-xl text-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary-container/20"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-on-surface-variant mb-1">
                    Indian Driving License Number
                  </label>
                  <input
                    type="text"
                    required
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    placeholder="e.g. DL-04-2021-9988776"
                    className="w-full h-11 px-3.5 bg-surface-container-low border border-border-purple-tint rounded-xl text-sm font-semibold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary-container/20 uppercase"
                  />
                  <span className="text-[11px] text-on-surface-variant mt-1 inline-block">
                    Physical license must be inspected by host during key handover.
                  </span>
                </div>
              </div>
            </div>

            {/* Trip Schedule Card */}
            <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-6 shadow-sm">
              <div className="flex items-center gap-2.5 pb-4 border-b border-border-purple-tint mb-4">
                <div className="w-8 h-8 rounded-xl bg-primary-container text-on-primary flex items-center justify-center">
                  <span className="material-symbols-outlined text-[18px]">calendar_month</span>
                </div>
                <h2 className="text-base font-bold text-on-surface">Trip Schedule & Pickup Hub</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3.5 rounded-2xl bg-surface-container-low border border-border-purple-tint/60">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">Pickup</span>
                  <div className="text-sm font-extrabold text-on-surface mt-0.5">
                    {new Date(startParam).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-xs text-on-surface-variant mt-1">{vehicle.pickup_location}</div>
                </div>

                <div className="p-3.5 rounded-2xl bg-surface-container-low border border-border-purple-tint/60">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">Return</span>
                  <div className="text-sm font-extrabold text-on-surface mt-0.5">
                    {new Date(endParam).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-xs text-on-surface-variant mt-1">Same Pickup Hub</div>
                </div>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-6 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-border-purple-tint mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-primary-container text-on-primary flex items-center justify-center">
                    <span className="material-symbols-outlined text-[18px]">payments</span>
                  </div>
                  <h2 className="text-base font-bold text-on-surface">Payment Gateway</h2>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-700 text-xs font-bold border border-amber-200">
                  Razorpay Test Mode
                </span>
              </div>

              <div className="flex flex-col gap-3">
                <label className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'razorpay_upi' ? 'border-primary bg-lavender-subtle/40' : 'border-border-purple-tint bg-surface-card'
                }`}>
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="razorpay_upi"
                      checked={paymentMethod === 'razorpay_upi'}
                      onChange={() => setPaymentMethod('razorpay_upi')}
                      className="accent-primary"
                    />
                    <div>
                      <div className="text-sm font-bold text-on-surface">Razorpay UPI / QR (Test Mode)</div>
                      <div className="text-xs text-on-surface-variant">GPay, PhonePe, Paytm, BHIM</div>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-primary text-[24px]">qr_code_scanner</span>
                </label>

                <label className={`flex items-center justify-between p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  paymentMethod === 'razorpay_card' ? 'border-primary bg-lavender-subtle/40' : 'border-border-purple-tint bg-surface-card'
                }`}>
                  <div className="flex items-center gap-3">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value="razorpay_card"
                      checked={paymentMethod === 'razorpay_card'}
                      onChange={() => setPaymentMethod('razorpay_card')}
                      className="accent-primary"
                    />
                    <div>
                      <div className="text-sm font-bold text-on-surface">Credit / Debit Card</div>
                      <div className="text-xs text-on-surface-variant">Visa, Mastercard, RuPay</div>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-primary text-[24px]">credit_card</span>
                </label>
              </div>
            </div>
          </div>

          {/* Right Order Summary & Pay Button (5 Cols) */}
          <div className="lg:col-span-5 sticky top-24">
            <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-6 shadow-xl flex flex-col gap-5">
              {/* Vehicle card snippet */}
              <div className="flex items-center gap-4 pb-4 border-b border-border-purple-tint">
                <img
                  src={vehicle.images?.[0]}
                  alt={vehicle.model}
                  className="w-20 h-16 rounded-xl object-cover shrink-0 border border-border-purple-tint"
                />
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-primary">{vehicle.brand}</span>
                  <h3 className="text-base font-bold text-on-surface">{vehicle.model}</h3>
                  <div className="text-xs text-on-surface-variant">{totalHours} Hours ({totalDays} Days)</div>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="flex flex-col gap-2.5 text-xs text-on-surface-variant">
                <div className="flex items-center justify-between">
                  <span>Base Vehicle Rental:</span>
                  <span className="font-bold text-on-surface">₹{baseRental.toLocaleString('en-IN')}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span>Insurance & Assistance Cover:</span>
                  <span className="font-bold text-on-surface">₹{insuranceFee}</span>
                </div>

                <div className="flex items-center justify-between">
                  <span>Convenience Fee & GST (5%):</span>
                  <span className="font-bold text-on-surface">₹{taxes}</span>
                </div>

                <div className="flex items-center justify-between text-emerald-600 font-semibold">
                  <span>Refundable Security Deposit:</span>
                  <span className="font-bold">₹0 (Waived)</span>
                </div>

                <div className="pt-3 mt-1 border-t border-border-purple-tint flex items-baseline justify-between text-sm">
                  <span className="font-extrabold text-on-surface">Amount Payable:</span>
                  <span className="text-2xl font-extrabold text-primary">₹{grandTotal.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Pay Button */}
              <button
                onClick={handlePayNow}
                disabled={paymentState === 'processing'}
                className="w-full h-12 bg-primary-container hover:bg-electric-violet-hover text-on-primary font-bold text-sm rounded-xl shadow-lg shadow-primary-container/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                {paymentState === 'processing' ? (
                  <>
                    <span className="inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    <span>Verifying with Razorpay...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[18px]">verified</span>
                    <span>Pay ₹{grandTotal.toLocaleString('en-IN')} (Razorpay Test)</span>
                  </>
                )}
              </button>

              <p className="text-[11px] text-center text-on-surface-variant leading-tight">
                By clicking pay, you authorize this test transaction. No real money will be deducted from your account.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* Confirmation State */
        <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-8 sm:p-12 shadow-xl max-w-2xl mx-auto w-full text-center flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-5 animate-in zoom-in-75">
            <span className="material-symbols-outlined text-[36px]">check_circle</span>
          </div>

          <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200 uppercase tracking-wider mb-2">
            Payment Confirmed
          </span>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-on-surface">Booking Reserved Successfully!</h2>
          <p className="text-xs sm:text-sm text-on-surface-variant max-w-md mt-2">
            Your booking request has been confirmed. The vehicle owner has been notified and pickup instructions have been issued.
          </p>

          <div className="w-full bg-surface-container-low rounded-2xl p-5 border border-border-purple-tint/60 my-6 text-left flex flex-col gap-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Booking Reference ID:</span>
              <span className="font-extrabold text-primary font-mono text-sm">{bookingRefId}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Vehicle:</span>
              <span className="font-bold text-on-surface">{vehicle.brand} {vehicle.model}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Pickup Hub:</span>
              <span className="font-bold text-on-surface">{vehicle.pickup_location}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-on-surface-variant">Total Paid (Razorpay Test):</span>
              <span className="font-extrabold text-primary text-sm">₹{grandTotal.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 w-full">
            <button
              onClick={() => navigate('/my-bookings')}
              className="px-6 py-3 rounded-xl bg-primary-container text-on-primary font-bold text-sm hover:bg-electric-violet-hover transition-all shadow-md"
            >
              Go to My Bookings
            </button>
            <button
              onClick={() => navigate('/explore')}
              className="px-6 py-3 rounded-xl bg-surface-container-low text-on-surface font-bold text-sm hover:bg-lavender-subtle transition-all"
            >
              Browse More Rides
            </button>
          </div>
        </div>
      )}
    </div>
  )
}


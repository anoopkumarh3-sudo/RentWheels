import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { MOCK_RENTAL_REQUESTS } from '../data/mockVehicles'
import UserAvatar from '../components/common/UserAvatar'
import { message } from 'antd'

export default function RentalRequestsPage() {
  const [requests, setRequests] = useState(MOCK_RENTAL_REQUESTS)

  const handleAction = (requestId, newStatus) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        return { ...req, status: newStatus }
      }
      return req
    }))

    if (newStatus === 'approved') {
      message.success('Rental request approved! The renter has been notified.')
    } else {
      message.info('Rental request declined.')
    }
  }

  const pendingRequests = requests.filter(r => r.status === 'pending')

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <nav className="flex items-center gap-1.5 text-xs text-on-surface-variant font-semibold mb-2">
          <Link to="/home" className="hover:text-primary">Home</Link>
          <span>/</span>
          <span className="text-primary font-bold">Rental Requests</span>
        </nav>

        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-4xl font-extrabold text-on-surface tracking-tight">
              Incoming Rental Requests
            </h1>
            <p className="text-xs sm:text-sm text-on-surface-variant mt-1">
              Review and manage booking applications submitted by renters for your vehicles.
            </p>
          </div>

          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-surface-card border border-border-purple-tint shadow-sm text-xs font-semibold text-on-surface">
            <span className={`w-2.5 h-2.5 rounded-full ${pendingRequests.length > 0 ? 'bg-amber-500 animate-pulse' : 'bg-gray-400'}`}></span>
            <span>{pendingRequests.length} Pending Approval</span>
          </div>
        </div>
      </div>

      {/* Requests List or Professional Empty State */}
      {requests.length > 0 ? (
        <div className="flex flex-col gap-5">
          {requests.map(req => (
            <div
              key={req.id}
              className="bg-surface-card rounded-3xl border border-border-purple-tint p-5 sm:p-6 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-6"
            >
              {/* Renter Profile & Trip Details */}
              <div className="flex items-start sm:items-center gap-4">
                <UserAvatar
                  name={req.renter.name}
                  imageUrl={req.renter.avatar}
                  size="lg"
                  showBadge={true}
                />

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-on-surface">{req.renter.name}</h3>
                    <span className="text-xs font-bold text-amber-500 flex items-center gap-0.5">
                      <span className="material-symbols-outlined text-[14px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                        star
                      </span>
                      <span>{req.renter.rating}</span>
                      <span className="text-on-surface-variant text-[10px]">({req.renter.trips} trips)</span>
                    </span>

                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      req.status === 'approved'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : req.status === 'declined'
                        ? 'bg-rose-50 text-rose-700 border border-rose-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}>
                      {req.status}
                    </span>
                  </div>

                  <div className="text-xs font-bold text-primary mt-1">
                    Requested Vehicle: <span className="text-on-surface">{req.vehicle_name}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-on-surface-variant mt-2">
                    <div className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-primary">schedule</span>
                      <span>{req.duration}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-[15px] text-primary">location_on</span>
                      <span>{req.pickup_hub}</span>
                    </div>

                    <div className="flex items-center gap-1 text-[11px] text-on-surface-variant/80">
                      <span>Received {req.requested_at}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Earnings & Host Actions */}
              <div className="flex items-center justify-between lg:justify-end gap-6 pt-4 lg:pt-0 border-t lg:border-t-0 border-border-purple-tint">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">Host Payout</div>
                  <div className="text-2xl font-extrabold text-emerald-600">₹{req.total_amount.toLocaleString('en-IN')}</div>
                  <div className="text-[10px] text-on-surface-variant font-medium">After platform fee</div>
                </div>

                {req.status === 'pending' ? (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleAction(req.id, 'declined')}
                      className="px-4 py-2 rounded-xl bg-surface-container-low text-error font-bold text-xs hover:bg-rose-50 transition-colors"
                    >
                      Decline
                    </button>

                    <button
                      onClick={() => handleAction(req.id, 'approved')}
                      className="px-5 py-2 rounded-xl bg-primary-container text-on-primary font-bold text-xs hover:bg-electric-violet-hover shadow-md shadow-primary/20 active:scale-95 transition-all"
                    >
                      Approve Request
                    </button>
                  </div>
                ) : (
                  <div className="text-xs font-bold text-on-surface-variant">
                    {req.status === 'approved' ? 'Request Accepted' : 'Request Declined'}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Professional Empty State */
        <div className="bg-surface-card rounded-3xl border border-border-purple-tint p-12 text-center flex flex-col items-center">
          <div className="w-16 h-16 rounded-2xl bg-lavender-subtle text-primary flex items-center justify-center mb-4">
            <span className="material-symbols-outlined text-[32px]">inbox</span>
          </div>
          <h3 className="text-lg font-bold text-on-surface">No rental requests right now</h3>
          <p className="text-xs sm:text-sm text-on-surface-variant max-w-sm mt-1 leading-relaxed">
            When renters book your vehicles, their requests will appear here for your review and approval.
          </p>
        </div>
      )}
    </div>
  )
}
